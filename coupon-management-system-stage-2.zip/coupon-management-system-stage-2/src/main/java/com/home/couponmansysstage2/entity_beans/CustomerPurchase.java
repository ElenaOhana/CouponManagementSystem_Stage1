package com.home.couponmansysstage2.entity_beans;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "customerPurchases")
@Builder
public class CustomerPurchase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne/*( cascade = CascadeType.PERSIST )*/ //TODO to check persist -doesn't work CLR with CascadeType.PERSIST
    @NotNull
    private Customer customer;

    @ManyToOne
    @NotNull
    private Coupon coupon;

    private String couponTitle; // My changes for view the name of Coupon in the table
    private String customerName;
    private LocalDateTime purchaseDateTime;

    public CustomerPurchase(Customer customer, Coupon coupon) {
        super();
        this.customer = customer;
        this.coupon = coupon;
        this.couponTitle = coupon.getTitle();
        this.customerName = customer.getFirstName(); // My changes for view the name of Game in the table
        this.purchaseDateTime = LocalDateTime.now();
    }

    public CustomerPurchase(Long id, Customer customer, Coupon coupon) {
        this.id = id;
        this.customer = customer;
        this.coupon = coupon;
        this.couponTitle = coupon.getTitle();
        this.customerName = customer.getFirstName(); // My changes for view the name of Game in the table
        this.purchaseDateTime = LocalDateTime.now();
    }
}
