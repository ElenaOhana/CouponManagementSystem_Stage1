package com.home.couponmansysstage2.exceptions;

public enum ErrMsg {
    COMPANY_NAME_EXISTS("company name is already exist"),
    COMPANY_EMAIL_EXISTS("company email is already exist"),
    COMPANY_EXISTS("company email is already exist"),
    ID_NOT_FOUND("Id not found"),
    UPDATE_ID("It is not allowed to change the company id."),
    UPDATE_NAME("It is not allowed to change the company name."),
    UPDATE_NO_MATCH("There is no matching between company id and name. (There is no company like you conveyed.)");

    private String errDescription;

    ErrMsg(String description) {
        this.errDescription = description;
    }

    public String getErrDescription() {
        return errDescription;
    }

    public void setErrDescription(String errDescription) {
        this.errDescription = errDescription;
    }
}
