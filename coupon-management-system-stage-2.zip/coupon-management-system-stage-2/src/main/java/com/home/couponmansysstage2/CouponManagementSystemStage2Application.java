package com.home.couponmansysstage2;

import com.home.couponmansysstage2.tests.TestService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
public class CouponManagementSystemStage2Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(CouponManagementSystemStage2Application.class, args);

		TestService testService = context.getBean(TestService.class);
		//testService.testAll(context); // Work with clr now
	}

	@Configuration
	//@EnableScheduling
	@ConditionalOnProperty(name = "scheduling.enabled", matchIfMissing = true)
	class schedulingConfiguration{

	}
}
