package com.home.couponmansysstage2.services;

import com.home.couponmansysstage2.entity_beans.Coupon;
import com.home.couponmansysstage2.exceptions.CouponSystemException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.transaction.Transactional;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Random;

@Service
@Transactional
@Slf4j
@Validated
@Data
@Scope(value = "prototype")
public class CompanyService extends ClientService{

    private Long companyId;

    //TODO
    public boolean login(String email, String password) {
        return false;
    }

    //TODO method, if we need to save the ID in service =>Service well be Scope(Prototype).
    public long loginCompanyReturnId(String email, String password) {
        return 0;
    }

    /**
     * The method receives the coupon and company Id,
     * gets to DB and bring all coupons and than checks:
     * 1) if each coupon belongs to received company,
     * 2) if the title of each coupon doesn't exists in received company,
     * 3) if company doesn't have this coupon -
     *  - the method adds received coupon,
     *  otherwise CouponSystemException is thrown.
     */
    // This method match for CompanyService as a Singleton! Do not use in this project!
    public Coupon createCoupon(@NotNull(message = "The Coupon must not be null") Coupon coupon,
                               @NotNull(message = "Company Id must not be null") Long companyId) throws CouponSystemException {
        boolean containsTitle = false;
        int counter = 0;
        Coupon coupon2;
        List<Coupon> allCouponList;
            allCouponList = couponRepository.findAll();
            System.out.println(allCouponList); // TODO remove
            if (coupon.getCompany().getId().equals(companyId)) { // changes the "WHERE coupons.companyId = company.companyId" query condition.
                for (Coupon coupon1 : allCouponList) {
                    String receivedTitle = coupon.getTitle();
                    String fromDBTitle = coupon1.getTitle();
                    if (receivedTitle.equals(fromDBTitle)) {
                        counter++;
                    }
                }
                if (counter > 0) {
                    containsTitle = true;
                }
                if (!allCouponList.contains(coupon) && !containsTitle) {
                    coupon2 = couponRepository.save(coupon);
                } else {
                    throw new CouponSystemException("An error has occurred. The coupon already exists.");
                }
            } else {
                throw new CouponSystemException("The action is illegal");
            }
        return coupon2;
    }

    /////////////////////////////TODO
    public void removeCoupon( Long id ) {

        // Validations, logic...
        couponRepository.deleteById(id);
    }

	/*
	public Optional<Coupon> getCouponById( Long id ) {
		return couponRepository.findById(id);
	}
	*/

	/*
	public Coupon getCouponById( Long id ) {
		return couponRepository.findById(id).get();
	}
	*/

    public Coupon getCouponById(Long id ) throws CouponSystemException {
        return couponRepository.findById(id).orElseThrow(
                () -> new CouponSystemException("No such coupon with ID " + id)	);
    }

    public List<Coupon> getAllCoupons(){
        return couponRepository.findAll();
    }
/*
	public List<Coupon> findCouponsByName( String name ) {
		return couponRepository.findByName(name);
	}

	public List<Coupon> findByPrice( double low, double high ) {
		return couponRepository.findByPriceBetween(low, high);
	}

	public List<Coupon> findByKeyword( String keyword ) {
		return couponRepository.findByKeyword(keyword);
	}

	public List<Coupon> findByKeyword2( String keyword ) {
		return couponRepository.findByKeyword(keyword);
	}*/

    @Transactional
    public void createCouponTwice( String name, double price ) {

        Coupon coupon1 = new Coupon();
        coupon1.setTitle(name);
        coupon1.setPrice(price);
        couponRepository.save(coupon1);

        if ( (new Random()).nextInt(2) == 0 ) {
            throw new RuntimeException("Fatal Error!");
        }

        Coupon coupon2 = new Coupon();
        coupon2.setTitle(name);
        coupon2.setPrice(price);
        couponRepository.save(coupon2);
    }

}
