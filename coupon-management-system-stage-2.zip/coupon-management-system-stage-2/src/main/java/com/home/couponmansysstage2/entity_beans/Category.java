package com.home.couponmansysstage2.entity_beans;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Data
@Table(name = "categories")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)/** IDENTITY - The counter for each table! */
    private Long id;

    @NotBlank
    @Size( min = 3, max = 45, message = "Category name must be between 3 and 45 characters")
    private String name;

    public Category(String name) {
        this.name = name;
    }

    /**
     * Bidirectional relation */
    @OneToMany(mappedBy = "category")
    @Singular
    private Collection<Coupon> coupons = new ArrayList<>();
}


