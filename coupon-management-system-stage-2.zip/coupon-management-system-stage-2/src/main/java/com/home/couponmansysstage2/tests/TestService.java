package com.home.couponmansysstage2.tests;

import com.home.couponmansysstage2.entity_beans.*;
import com.home.couponmansysstage2.exceptions.CouponSystemException;
import com.home.couponmansysstage2.repositories.CategoryRepository;
import com.home.couponmansysstage2.security.LoginManager;
import com.home.couponmansysstage2.services.*;
import com.home.couponmansysstage2.types.CouponStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.time.LocalDateTime;
import java.util.Set;

@Service
@Transactional
@Slf4j
public class TestService {

    @Autowired
    LoginManager loginManager;

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    CompanyService companyService;

    @Autowired
    CustomerService customerService;

    @Autowired
    AdminServiceImpl adminServiceImpl;

    public void testAll(ConfigurableApplicationContext context){

        // I've changed it to straight access to categoryRepository because we don't need the CategoryService,
        // moreover, after using clr we won't need this class!
        Category shoppingCategory = new Category("Shopping");
        categoryRepository.save(shoppingCategory);

        Category travelingCategory = new Category("traveling");
        categoryRepository.save(travelingCategory);

        Category sportCategory = new Category("sport");
        categoryRepository.save(sportCategory);

        LocalDateTime startDate = LocalDateTime.of(2021,12,03, 00,00);
        LocalDateTime endDate = LocalDateTime.of(2021,12,05, 00,00);

        Company carCompany = null;
        try {
            carCompany = adminServiceImpl.addCompany(new Company("Kal-Car", "kal_carnew@calcar.co.il", "1111"));
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }
        Company sportAtCountries = null;
        try {
            sportAtCountries = adminServiceImpl.addCompany(new Company("sportAtCountries", "country_sp@countrysp.com", "2222"));
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }
        //log.info("***************** carCompany has a ClientStatus: " + carCompany.getClientStatus());

        Coupon hondaDreamCoupon = null;
        Coupon myTravelCoupon = null;

        try {
            hondaDreamCoupon = companyService.createCoupon(new Coupon(null, carCompany, shoppingCategory, "Honda dream day", "Honda dream day", startDate, endDate, 10,150000, null, CouponStatus.ABLE), carCompany.getId());
        } catch (CouponSystemException e) {
            e.printStackTrace();
            System.err.println(e.getMessage());// TODO Solution to check
        }
        try {
            myTravelCoupon = companyService.createCoupon(new Coupon(null, sportAtCountries, travelingCategory, "my Travel Coupon", "Travel in South", startDate, endDate, 10,200, null, CouponStatus.ABLE), sportAtCountries.getId());
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }

        //log.info("***************** hondaDreamCoupon has an amount: " + hondaDreamCoupon.getAmount());


        System.out.println();//TODO it in the start by this order: Category, Company, Customer, Coupon.
        System.out.println("----------------------The check by Validator class before continue to work with services------------------");
        Validator validator = context.getBean(Validator.class);
        Coupon coupon = new Coupon();
        coupon.setAmount(1);
        coupon.setCompany(sportAtCountries); //TODO To change according the old table
        coupon.setCategory(sportCategory);  //TODO To change according the old table
        coupon.setDescription("Body wellness day");
        coupon.setTitle("Yoga for everyone");
        coupon.setPrice(200);
        coupon.setStartDate(startDate);
        coupon.setEndDate(endDate);
        Set<ConstraintViolation<Coupon>> constraintViolations = validator.validate(myTravelCoupon);

        if ( constraintViolations.isEmpty() ) {
            System.out.println( "The coupon object passed all validations!" );
        } else {
            System.out.println( constraintViolations.size() + " violations were found!" );
            for ( ConstraintViolation<Coupon> constraintViolation : constraintViolations ) {
                System.out.println( constraintViolation.getMessage() );
            }
        }


		Customer mariaCustomer = customerService.createCustomer(new Customer("Maria", "Gorovich", "maria_go@gmail.com", "1234"));

		customerService.createCustomerPurchase(new CustomerPurchase(mariaCustomer, hondaDreamCoupon));

        //customerRepository.findAll().forEach(System.out::println);


    }
}
