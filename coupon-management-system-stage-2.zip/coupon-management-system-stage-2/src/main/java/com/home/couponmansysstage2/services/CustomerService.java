package com.home.couponmansysstage2.services;

import com.home.couponmansysstage2.entity_beans.Customer;
import com.home.couponmansysstage2.entity_beans.CustomerPurchase;
import com.home.couponmansysstage2.exceptions.CouponSystemException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.transaction.Transactional;

@Service
@Transactional
@Slf4j
@Validated
@Data
@Scope(value = "prototype")
public class CustomerService extends  ClientService{
    private Long customerId;

    //TODO
    public boolean login(String email, String password) {
        return false;
    }

    public long loginCustomerReturnId(String email, String password) {
        return 0;
    }

    public Customer createCustomer(Customer customer) {
        // TODO Validations (not null, not already exist...)
        return customerRepository.save(customer);
    }

    public void removeCustomer(Long id) {
        // TODO Validations, logic...
        customerRepository.deleteById(id);
    }

    public Customer getCustomerById(Long id) throws CouponSystemException {
        return customerRepository.findById(id).orElseThrow(
                () -> new CouponSystemException("No such customer with ID " + id));
    }

    /**
     * Work in front CustomerPurchaseRepository */
    public CustomerPurchase createCustomerPurchase(CustomerPurchase customerPurchase) {
        // TODO Validations (not null, not already exist...)
        return customerPurchaseRepository.save(customerPurchase);
    }

    public void removeCustomerPurchase(Long id) {
        // TODO Validations, logic...
        customerPurchaseRepository.deleteById(id);
    }

    public CustomerPurchase getCustomerPurchaseById(Long id) throws CouponSystemException {
        return customerPurchaseRepository.findById(id).orElseThrow(
                () -> new CouponSystemException("No such customer purchase with ID " + id));
    }
}
