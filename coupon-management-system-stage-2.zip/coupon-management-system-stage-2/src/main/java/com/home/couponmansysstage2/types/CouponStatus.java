package com.home.couponmansysstage2.types;

public enum CouponStatus {
    ABLE, DISABLE
}
