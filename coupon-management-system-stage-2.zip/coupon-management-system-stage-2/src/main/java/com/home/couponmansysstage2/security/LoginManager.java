package com.home.couponmansysstage2.security;

import com.home.couponmansysstage2.exceptions.CouponSystemException;
import com.home.couponmansysstage2.services.AdminServiceImpl;
import com.home.couponmansysstage2.services.ClientService;
import com.home.couponmansysstage2.services.CompanyService;
import com.home.couponmansysstage2.services.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service//With Koby
@RequiredArgsConstructor // Injects @(Autowired) on C'tor off all final attributes!
//@Transactional // Todo ?? not need
public class LoginManager {

        private final ApplicationContext context;
        private final AdminServiceImpl adminService; // Singleton
        private final CompanyService companyService; // Prototype
        private final CustomerService customerService; // Prototype
/*
* The method log in the client:
* the method checks by email and password param if client exists, and by clientType param which ClientFacade should return.
* returns an abstract client facade if the client exists(has the correct credentials) and has correct client type, otherwise throws CouponSystemException.
 * null is returned when the ClientType doesn't exists.*/
    public ClientService login(String email, String password, ClientType clientType) throws CouponSystemException {
        ClientService clientService = null;
        if (clientType == ClientType.ADMINISTRATOR) {
            if (clientService.login(email, password)) {
                ClientService adminService = context.getBean(AdminServiceImpl.class);

                //ClientService adminService = context.getBean(AdminService.class);
            return adminService;
            }
        } else if (clientType == ClientType.COMPANY) {
            if (clientService.login(email,password)) {
                long companyId = companyService.loginCompanyReturnId(email,password); // Todo method, if we need to save the ID in service =>Service will be Scope(Prototype).
                ClientService companyService = context.getBean(CompanyService.class);
                ((CompanyService) companyService).setCompanyId(companyId);
                return companyService;
            }
        } else if (clientType == ClientType.CUSTOMER) {
            if (clientService.login(email, password)) {
                long customerId = customerService.loginCustomerReturnId(email, password);
                ClientService customerService = context.getBean(CustomerService.class);
                ((CustomerService)customerService).setCustomerId(customerId);
                return customerService;
            }
        }
        return null;
    }

   /* shakedbenratzon@outlook.com
0525212575*/
    /*
    * public CompanyServiceImpl(CompanyRepository companyRepository, CustomerRepository customerRepository,
			CouponRepository couponRepository) {
		super(companyRepository, customerRepository, couponRepository);
	}
Company res = companyRepository.findCompanyByEmailAndPassword(email, password);
		if (res != null) {
			this.companyId = res.getId();
			return true;
		}
		return false;
	}
*/
}
