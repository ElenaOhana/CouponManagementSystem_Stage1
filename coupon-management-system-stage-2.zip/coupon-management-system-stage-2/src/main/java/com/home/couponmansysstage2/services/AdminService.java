package com.home.couponmansysstage2.services;

import com.home.couponmansysstage2.entity_beans.Company;
import com.home.couponmansysstage2.exceptions.CouponSystemException;

import javax.validation.constraints.NotNull;
import java.sql.SQLException;
import java.util.List;

public interface AdminService {
     boolean isCompanyExists(String email, String password);
     Company addCompany(@NotNull Company company) throws CouponSystemException;
     Company addCompany2(@NotNull Company company) throws CouponSystemException;
     void updateCompany(@NotNull Company company) throws CouponSystemException;
     /**
      * This method changes company status to INACTIVE. */
     void deleteCompanyAsChangeStatus(@NotNull Long companyID) throws CouponSystemException;
     List<Company> getAllCompanies();
     Company getOneCompany(Long id) throws CouponSystemException;


   /*  Company getCompanyByName(String name) throws SQLException;
     Company getCompanyByEmail(String email) throws SQLException;*/

}
