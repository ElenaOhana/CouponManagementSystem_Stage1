package com.home.couponmansysstage2.clr;

import com.home.couponmansysstage2.entity_beans.*;
import com.home.couponmansysstage2.repositories.*;
import com.home.couponmansysstage2.types.ClientStatus;
import com.home.couponmansysstage2.types.CouponStatus;
import com.home.couponmansysstage2.utils.ArtUtils;
import lombok.RequiredArgsConstructor;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;

@Component
@Order(1)
@RequiredArgsConstructor
public class DummyData implements CommandLineRunner {
    /**
     * CommandLineRunner is a simple Spring Boot interface with a run method.
     * Spring Boot will automatically call the run method of all beans implementing
     * this interface after the application context has been loaded.
     * CommandLineRunner is an interface used to indicate that a bean should run
     * when it is contained within a SpringApplication.
     * A Spring Boot application can have multiple beans implementing CommandLineRunner.
     * These can be ordered with @Order .*/

    //@Autowired // instead of @RequiredArgsConstructor + final
    private final CustomerRepository customerRepository;
    private final CompanyRepository companyRepository;
    private final CategoryRepository categoryRepository;
    private final CouponRepository couponRepository;
    private final CustomerPurchaseRepository customerPurchaseRepository;


    @Override
    public void run(String... args) throws Exception {
        System.out.println(ArtUtils.CUSTOMERS);
        Customer customer1 = Customer.builder()
                .firstName("Avi")
                .lastName("Meshulam")
                .email("avi@g,gmail.com")
                .password("1234")
                .clientStatus(ClientStatus.ACTIVE)
                .build();

        Customer customer2 = Customer.builder()
                .firstName("Reshef")
                .lastName("Kama")
                .email("eeshef@g,gmail.com")
                .password("5678")
                .clientStatus(ClientStatus.ACTIVE)
                .build();

        Customer customer3 = Customer.builder()
                .firstName("Elena")
                .lastName("Petina")
                .email("elena_pe@gmail.com")
                .password("777")
                .clientStatus(ClientStatus.ACTIVE)
                .build();

        customerRepository.saveAll(Arrays.asList(customer1,customer2,customer3));
        customerRepository.findAll().forEach(System.out::println);//println forEach

        System.out.println(ArtUtils.COMPANIES);
        Company company1 = Company.builder()
                .name("Cola")
                .email("cola@gmail.com")
                .password("1234")
                .clientStatus(ClientStatus.ACTIVE)
                .build();

        Company company2 = Company.builder()
                .name("Pepsi")
                .email("pepsi@gmail.com")
                .password("3232")
                .clientStatus(ClientStatus.ACTIVE)
                .build();

        Company company3 = Company.builder()
                .name("Ivory")
                .email("ivory@gmail.com")
                .password("5555")
                .clientStatus(ClientStatus.ACTIVE)
                .build();

        companyRepository.saveAll(Arrays.asList(company1,company2,company3));
        companyRepository.findAll().forEach(System.out::println);

        System.out.println(ArtUtils.CATEGORIES);
        Category category1 = Category.builder()
                .name("Shopping")
                .build();

        Category category2 = Category.builder()
                .name("Sport")
                .build();

        Category category3 = Category.builder()
                .name("PC")
                .build();

        Category category4 = Category.builder()
                .name("Traveling")
                .build();

        categoryRepository.saveAll(Arrays.asList(category1, category2, category3, category4));
        categoryRepository.findAll().forEach(System.out::println);

        Coupon coupon1 = Coupon.builder()
                .company(companyRepository.getOne(1L))
                .category(categoryRepository.getOne(1L))
                .title("1+1")
                .description("all drinks")
                .startDate(LocalDateTime.now())
                .endDate(LocalDateTime.now().plusDays(12))
                .amount(100)
                .price(9.9)
                .image("https://picsum.photos/200")
                .status(CouponStatus.ABLE)
                .build();

        Coupon coupon2 = Coupon.builder()
                .company(companyRepository.getOne(2L))
                .category(categoryRepository.getOne(1L))
                .title("1+1")
                .description("all Pepsi drinks")
                .startDate(LocalDateTime.now())
                .endDate(LocalDateTime.now().plusDays(15))
                .amount(100)
                .price(8.9)
                .image("https://picsum.photos/200")
                .status(CouponStatus.ABLE)
                .build();

        Coupon coupon3 = Coupon.builder()
                .company(companyRepository.getOne(3L))
                .category(categoryRepository.getOne(3L))
                .title("2+1")
                .description("all printers")
                .startDate(LocalDateTime.now())
                .endDate(LocalDateTime.now().plusDays(12))
                .amount(100)
                .price(9.9)
                .image("https://picsum.photos/200")
                .status(CouponStatus.ABLE)
                .build();

        System.out.println(ArtUtils.COUPONS);
        couponRepository.saveAll(Arrays.asList(coupon1,coupon2,coupon3));
        couponRepository.findAll().forEach(System.out::println);

        CustomerPurchase customerPurchase1 = CustomerPurchase.builder()
                .customer(customerRepository.getCustomerById(1L))
                .coupon(couponRepository.getCouponById(1L))
                .couponTitle(couponRepository.getOne(1L).getTitle())
                .customerName(customerRepository.getOne(1L).getFirstName())
                .purchaseDateTime(LocalDateTime.now())
                .build();

        CustomerPurchase customerPurchase2 = CustomerPurchase.builder()
                .customer(customerRepository.getCustomerById(2L))
                .coupon(couponRepository.getCouponById(2L))
                .couponTitle(couponRepository.getOne(2L).getTitle())
                .customerName(customerRepository.getOne(2L).getFirstName())
                .purchaseDateTime(LocalDateTime.now())
                .build();

        CustomerPurchase customerPurchase3 = CustomerPurchase.builder()
                .customer(customerRepository.getCustomerById(3L))
                .coupon(couponRepository.getCouponById(3L))
                .couponTitle(couponRepository.getOne(3L).getTitle())
                .customerName(customerRepository.getOne(3L).getFirstName())
                .purchaseDateTime(LocalDateTime.now())
                .build();

        System.out.println(ArtUtils.CUSTOMERS_PURCHASES);
        customerPurchaseRepository.saveAll(Arrays.asList(customerPurchase1, customerPurchase2, customerPurchase3));
        customerPurchaseRepository.findAll().forEach(System.out :: println);
    }
}
