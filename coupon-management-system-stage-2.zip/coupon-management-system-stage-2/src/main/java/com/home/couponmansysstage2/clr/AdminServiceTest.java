package com.home.couponmansysstage2.clr;

import com.home.couponmansysstage2.entity_beans.Company;
import com.home.couponmansysstage2.repositories.CompanyRepository;
import com.home.couponmansysstage2.services.AdminService;
import com.home.couponmansysstage2.services.ClientService;
import com.home.couponmansysstage2.types.ClientStatus;
import com.home.couponmansysstage2.utils.ArtUtils;
import com.home.couponmansysstage2.utils.TestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Order(2)
@Component
public class AdminServiceTest implements CommandLineRunner {
    @Autowired
    private AdminService adminService;
    @Autowired
    private CompanyRepository companyRepository;

    @Override
    public void run(String... args) throws Exception {
        System.out.println(ArtUtils.ADMIN_SERVICE);
        TestUtils.printTest("bad logging");
        System.out.println(((ClientService)adminService).login("katy@gmail.com", "1111"));
        TestUtils.printTest("good logging");
        System.out.println(((ClientService)adminService).login("admin@admin.com", "admin"));
        Company existingCompany= companyRepository.getOne(1L);
        Company companyToAdd = Company.builder()
                .name(existingCompany.getName())
                .email("elena@gmail.com")
                .password("5757")
                .clientStatus(ClientStatus.ACTIVE)
                .build();

        TestUtils.printTest("add company will fail due to existing name");
        try {
            adminService.addCompany2(companyToAdd);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        TestUtils.printTest("add company will fail due to existing mail");
        companyToAdd.setName("Elena LTD");
        companyToAdd.setEmail(existingCompany.getEmail());
        try {
            adminService.addCompany2(companyToAdd);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        TestUtils.printTest("add company will success");
        companyToAdd.setEmail("elena@gmail.com");
        try {
            adminService.addCompany2(companyToAdd);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        companyRepository.findAll().forEach(System.out :: println);

        /////////////////////////////////////////////////////

        TestUtils.printTest("update company will fail due to not allowed to change the company name");
        existingCompany.setName("Choco-Pie");
        try {
            adminService.updateCompany(existingCompany);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        TestUtils.printTest("update company will fail due to not allowed to change the company id");
        existingCompany.setName("Cola");
        existingCompany.setId(2L);
        System.out.println("existingCompany is : " + existingCompany);
        try {
            adminService.updateCompany(existingCompany);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        TestUtils.printTest("update company will fail due to trying to change the company with other Id/or with other name.");
        existingCompany.setEmail("cola_cola_upd@gmail.com");
        try {
            adminService.updateCompany(existingCompany);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        TestUtils.printTest("update company email will success");
        existingCompany.setId(1L);
        existingCompany.setEmail("cola_cola_upd@gmail.com");
        try {
            adminService.updateCompany(existingCompany);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println(companyRepository.getCompanyById(1L));

        TestUtils.printTest("update company password will success");
        existingCompany.setPassword("222222");
        try {
            adminService.updateCompany(existingCompany);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        companyRepository.findAll().forEach(System.out :: println);


        //DELETE COMPANY//////////////////////////DELETE COMPANY////////////////////////DELETE COMPANY
        TestUtils.printTest("delete company will fail due to passing not existing id.");
        try {
            adminService.deleteCompanyAsChangeStatus(10L);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        TestUtils.printTest("delete company will success");
        try {
            adminService.deleteCompanyAsChangeStatus(1L);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        companyRepository.findAll().forEach(System.out :: println);
    }
}
