package com.home.couponmansysstage2.daily_job;

import com.home.couponmansysstage2.entity_beans.Coupon;
import com.home.couponmansysstage2.repositories.CouponRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
@Slf4j
/**
 * Singleton by default as Spring bean */
public class CouponExpirationDailyJob {
    @Autowired
    CouponRepository couponRepository;

    @Scheduled(initialDelayString = "PT3S" , fixedRateString = "${job.delay}") // Job that run every 2000 milliseconds
    //@Scheduled(cron = "00 00 * * */1") // “At 00:00 on every day-of-week.” == @Scheduled(cron = "@daily")
    //@Scheduled(fixedRate = 1000*60*60*24)
    public void updateCouponStatusAsDeleteCoupon() {
        log.info("**************Updating Status to DISABLE************");
        List<Coupon> couponList = couponRepository.findAll();
        /*for (Coupon coupon : couponList) {
           *//* if (coupon.getEndDate().isBefore(LocalDateTime.now())) {
                try {
                    couponsDAO.deleteCouponAsChangeStatus(coupon.getId());  // changes status to DISABLE
                    List<Integer> customerIdOfExpiredCoupons = couponsDAO.getCustomersIdFromCustomersVsCoupons(coupon.getId());
                    for (Integer customerIdOfExpiredCoupon : customerIdOfExpiredCoupons) {
                        customersDAO.deleteCustomerPurchase(customerIdOfExpiredCoupon); // deletes customer purchases
                    }
                } catch (InternalSystemException e) {
                    throw new RuntimeException("DB error from CouponExpirationDailyJob.", e);
                }
            }*//*
        }*/
    }
}
