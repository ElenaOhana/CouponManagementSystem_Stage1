package com.home.couponmansysstage2.services;

import com.home.couponmansysstage2.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/*
 * Created by Elena on 30 June, 2021
 */
@Service
public abstract class ClientService {

    @Autowired
    protected CompanyRepository companyRepository;

    @Autowired
    protected CustomerRepository customerRepository;

    @Autowired
    protected CouponRepository couponRepository;

    @Autowired
    protected CustomerPurchaseRepository customerPurchaseRepository;

    @Autowired
    protected CategoryRepository categoryRepository;

    public abstract boolean login(String email, String password);

}
