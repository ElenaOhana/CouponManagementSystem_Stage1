package com.home.couponmansysstage2.repositories;


import com.home.couponmansysstage2.entity_beans.Coupon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CouponRepository extends JpaRepository<Coupon, Long> {

    Coupon getCouponById(Long id);

    // @Query("select c from Coupons coup where coup.companyId = ?1") // במחלקת קופונים  companyIdלא מאים כי אין
    List<Coupon> findCompanyCouponsByCompanyId(Long companyId); // (company.getId); ??

    List<Coupon> findAllById(Long companyId);


    /*@Override
    <S extends Coupon> List<S> findAll(Example<S> example);*/ //???
/*

	// We can make Spring conclude the query from the method name:
	List<Coupon> findByName(String name );
	List<Coupon> findByPriceBetween( double low, double high );
	
	// Or, we can provide Spring with the query (JPQL):
	@Query("select c from Coupon c where c.name like %:keyword%")
	List<Coupon> findByKeyword( String keyword );

	// Or, we can provide Spring with the query (JPQL):
	@Query("select c from Coupon c where c.name like %?1%") // The same as before
	List<Coupon> findByKeyword2( String keyword );
*/

    /*
    * public interface UserRepository extends JpaRepository<User, Long> {
      @Query("select u from User u where u.firstname like %?1")
      List<User> findByFirstnameEndsWith(String firstname);
    }*/

}
