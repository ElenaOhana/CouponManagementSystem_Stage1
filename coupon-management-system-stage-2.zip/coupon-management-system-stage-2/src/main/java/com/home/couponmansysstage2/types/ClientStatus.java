package com.home.couponmansysstage2.types;

public enum ClientStatus {
    ACTIVE, INACTIVE
}
