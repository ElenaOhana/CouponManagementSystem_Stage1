package com.home.couponmansysstage2.security;

public enum ClientType {
    ADMINISTRATOR, COMPANY,CUSTOMER
}
