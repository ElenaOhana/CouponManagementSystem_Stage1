package com.home.couponmansysstage2.entity_beans;

import com.home.couponmansysstage2.types.CouponStatus;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.Objects;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "coupons")
@Builder
@Data
public class Coupon {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // strategy = GenerationType.IDENTITY => AI
    private Long id;

    @ManyToOne
    @NotNull
    @ToString.Exclude
    private Company company; /** Relation Owner, FK */

    @ManyToOne
    @NotNull
    @ToString.Exclude
    private Category category;

    /**
     * The title can changes from Company to Company => title not unique */
    @Column(nullable = false, length = 45)
    @Size( min = 2, max = 45, message = "Coupon title must be between 2 and 45 characters")
    private String title;

    @Column(nullable = false)
    @Lob
    private String description;

    @NotNull
    private LocalDateTime startDate;
    @NotNull
    private LocalDateTime endDate;

    @ColumnDefault("0")
    private int amount = 0;

    @NotNull
    private double price;

    private String image;

    /**
     * Default value of enum CouponStatus is ABLE */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 45)
    CouponStatus status = CouponStatus.ABLE;

   /* public Coupon(Long id, Company company, Category category, String title, String description, LocalDateTime startDate, LocalDateTime endDate, int amount, double price, String image, CouponStatus status) {
        this.id = id;
        this.company = company;
        this.category = category;
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.amount = amount;
        this.price = price;
        this.image = image;
        this.status = status;
    }

    public Coupon(Company company, Category category, String title, String description, LocalDateTime startDate, LocalDateTime endDate, int amount, double price, String image) {
        this.company = company;
        this.category = category;
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.amount = amount;
        this.price = price;
        this.image = image;
    }*/


   /* @Override
    public String toString() {
        return "Coupon{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", amount=" + amount +
                ", price=" + price +
                ", image='" + image + '\'' +
                ", status=" + status +
                '}';
    }*/

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Coupon)) return false;
        Coupon coupon = (Coupon) o;
        return Objects.equals(getId(), coupon.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }
}
