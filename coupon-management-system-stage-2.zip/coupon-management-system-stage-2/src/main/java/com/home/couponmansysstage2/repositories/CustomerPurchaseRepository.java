package com.home.couponmansysstage2.repositories;

import com.home.couponmansysstage2.entity_beans.CustomerPurchase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerPurchaseRepository extends JpaRepository<CustomerPurchase, Long> {

    CustomerPurchase getCustomerPurchasesByCustomerId(Long id);
    CustomerPurchase getCustomerPurchasesByCouponId(Long id);
}
