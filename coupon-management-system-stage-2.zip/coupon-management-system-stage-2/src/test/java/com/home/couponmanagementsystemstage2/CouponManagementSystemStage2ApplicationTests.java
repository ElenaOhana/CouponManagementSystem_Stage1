package com.home.couponmansysstage2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponManagementSystemStage2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
